function [ f_h_c ] = F_H_C( h,alpha_h,h0 )

for i=1:2
    for j=1:2
        % ����beta
        beta(i,j)=Beta(h(i,j),90,100);
        % ����f_h_c
        f_h_c(i,j)=alpha_h*beta(i,j)*(h(i,j)-h0^2/h(i,j));
    end
end

end

