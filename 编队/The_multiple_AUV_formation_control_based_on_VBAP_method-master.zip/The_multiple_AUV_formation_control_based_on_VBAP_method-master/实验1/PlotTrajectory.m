function [] = PlotTrajectory( t,x,y )
%PLOTTRAJECTORY �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
plot(x,y)
h = line('xdata',[],'ydata',[],'color','r','marker','.','markersize',30);
% i=0;
for ii=1:length(x)
    set(h,'xdata',x(ii),'ydata',y(ii));
%     figure();
%     plot(x(ii),y(ii))
    drawnow 
    pause(t/20)
%     i=i+1;
%     print(gcf,'-dbmp',sprintf('%d',i))
%     close;
end
% for j=1:ii
%     A=imread(sprintf('112233/%d.bmp',j));
%     [I,map]=rgb2ind(A,256);
%     if(j==1)
%         imwrite(I,map,'movefig.gif','DelayTime',0.1,'LoopCount',Inf)
%     else
%         imwrite(I,map,'movefig.gif','WriteMode','append','DelayTime',0.1)    
%     end
% end
end

