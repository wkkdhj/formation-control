function [ beta ] = Beta( x,a,b )
%BETA 此处显示有关此函数的摘要
%   此处显示详细说明
if x<=a
    beta=1;
elseif x>b
    beta=0;
else
    beta=(sin((pi/2)*((x-b)/(a-b))))^2;
end      
end

