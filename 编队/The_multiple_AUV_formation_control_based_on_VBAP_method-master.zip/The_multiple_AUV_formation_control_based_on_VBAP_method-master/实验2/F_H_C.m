function [ f_h_c ] = F_H_C( h,alpha_h,h0 )

for i=1:3
    j=1;
    % ����beta
    beta(i,j)=Beta(h(i),90,100);
    % ����f_h_c
    f_h_c(i,j)=alpha_h*beta(i)*(h(i)-h0^2/h(i));
end

end

